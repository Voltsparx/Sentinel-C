# Sentinel-C v4.5 (Windows x86_64)

Author: voltsparx
Contact: voltsparx@gmail.com

Package contents:
- bin/sentinel-c.exe
- docs/
- Usage.txt
- LICENSE
- SHA256SUMS.txt

Quick start (PowerShell):
1. .\\bin\\sentinel-c.exe --help
2. .\\bin\\sentinel-c.exe --doctor
3. .\\bin\\sentinel-c.exe --init "C:\\Path\\To\\Target"
