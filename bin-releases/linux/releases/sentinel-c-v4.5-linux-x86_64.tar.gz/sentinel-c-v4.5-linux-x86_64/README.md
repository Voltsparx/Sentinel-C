# Sentinel-C v4.5 (Linux x86_64)

Author: voltsparx
Contact: voltsparx@gmail.com

Package contents:
- bin/sentinel-c
- docs/
- Usage.txt
- LICENSE
- SHA256SUMS.txt

Quick start:
1. chmod +x bin/sentinel-c
2. ./bin/sentinel-c --help
3. ./bin/sentinel-c --doctor
4. ./bin/sentinel-c --init /path/to/target
